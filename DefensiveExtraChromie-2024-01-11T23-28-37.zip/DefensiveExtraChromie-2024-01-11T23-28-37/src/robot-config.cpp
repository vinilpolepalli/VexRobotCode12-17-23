#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
extern motor TopLeftMotor;
extern motor TopRightMotor;
extern motor BottomLeftMotor;
extern motor BottomRightMotor;
extern controller Controller1;
extern motor LauncherTop;
extern motor LauncherBottom;

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.

 * This should be called at the start of your int main function.
 */

bool Controller1LeftShoulderControlMotorsStopped = true;
bool Controller1RightShoulderControlMotorsStopped = true;
bool Controller1UpDownButtonsControlMotorsStopped = true;
bool Controller1XBButtonsControlMotorsStopped = true;

  // process the controller input every 20 milliseconds
  // update the motors based on the input values
 
void vexcodeInit( void ) {
  // nothing to initialize
}